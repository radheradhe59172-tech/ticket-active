<?php
// Frontend page - ticket check form
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Check Ticket - Mega Lottery</title>
<link rel="stylesheet" href="css/style.css">
<meta name="viewport" content="width=device-width,initial-scale=1">
</head>
<body>
<div class="container">
  <h1>Check Your Ticket</h1>
  <form method="GET" action="check.php">
    <label>Mobile Number
      <input type="text" name="phone" maxlength="15" required>
    </label>
    <label>Ticket Number
      <input type="text" name="ticket_number" maxlength="100" required>
    </label>
    <button type="submit">Check</button>
  </form>
  <p>Or use the original form page layout if you want to keep your design. This is a minimal functional page.</p>
</div>
</body>
</html>
