Ticket Activation System - Quick Install
--------------------------------------

1. Create the database and table:
   - Import the SQL file 'db.sql' into your MySQL server (e.g., using phpMyAdmin or mysql CLI).
     This creates database 'ticket_system' and table 'tickets'.

2. Upload files to your PHP host (document root):
   - Copy all files and folders from the ZIP to your public_html or site folder.
   - Ensure 'config.php' has correct DB credentials (DB_HOST, DB_NAME, DB_USER, DB_PASS).
   - Change ADMIN_PASS in config.php immediately to a secure password.

3. Admin:
   - Visit /admin/login.php to login (default user: admin, password: ChangeMe123!).
   - Use 'Upload CSV' to bulk-import tickets. CSV format: ticket_number,status
     Example rows: ABC123,active
                   XYZ999,winner

4. User flow:
   - Visit index.php to check a ticket. Enter ticket number and phone (phone is optional in lookup here).
   - Result page will display ticket status.

5. Security & Notes:
   - This is a basic system. For production, add HTTPS, stronger auth, rate-limiting, and CSRF protection.
   - Ensure file uploads size limits and permissions are configured correctly on the server.
