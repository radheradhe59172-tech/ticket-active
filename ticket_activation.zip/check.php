<?php
require 'db.php';

$phone = trim($_GET['phone'] ?? '');
$ticket_number = trim($_GET['ticket_number'] ?? '');

// Simple validation
if ($phone === '' || $ticket_number === '') {
    echo '<p>Please provide phone and ticket number. <a href="index.php">Back</a></p>';
    exit;
}

// Lookup by ticket_number
$stmt = $pdo->prepare('SELECT ticket_number, status, created_at FROM tickets WHERE ticket_number = ? LIMIT 1');
$stmt->execute([$ticket_number]);
$ticket = $stmt->fetch();

?>
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Ticket Result</title><link rel="stylesheet" href="css/style.css"></head><body>
<div class="container">
  <h1>Ticket Result</h1>
<?php if ($ticket): ?>
    <p><strong>Ticket Number:</strong> <?php echo htmlspecialchars($ticket['ticket_number']); ?></p>
    <p><strong>Status:</strong> <?php echo htmlspecialchars(strtoupper($ticket['status'])); ?></p>
    <p><small>Registered at: <?php echo htmlspecialchars($ticket['created_at']); ?></small></p>
    <?php if ($ticket['status'] === 'winner'): ?>
      <div class="winner-box">Congratulations! This ticket is a WINNER.</div>
    <?php elseif ($ticket['status'] === 'active'): ?>
      <div class="active-box">Your ticket is ACTIVE.</div>
    <?php else: ?>
      <div class="inactive-box">This ticket is inactive.</div>
    <?php endif; ?>
<?php else: ?>
    <p>No record found for that ticket number.</p>
<?php endif; ?>
  <p><a href="index.php">Check another ticket</a></p>
</div>
</body></html>
