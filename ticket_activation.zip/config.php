<?php
// config.php - update before production
define('DB_HOST', 'localhost');
define('DB_NAME', 'ticket_system');
define('DB_USER', 'root');
define('DB_PASS', '');

// Admin credentials (change immediately)
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'ChangeMe123!');

// Base URL (optional) - set if site is in subfolder or to generate absolute links
// define('BASE_URL', 'https://yourdomain.com/');
define('BASE_URL', '');
?>