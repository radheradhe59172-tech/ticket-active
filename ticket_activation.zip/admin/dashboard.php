<?php
session_start();
if (empty($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Admin Dashboard</title><link rel="stylesheet" href="../css/style.css"></head><body>
<div class="container">
  <h1>Admin Dashboard</h1>
  <ul>
    <li><a href="tickets.php">View/Search Tickets</a></li>
    <li><a href="upload.php">Upload CSV (bulk tickets)</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</div>
</body></html>
