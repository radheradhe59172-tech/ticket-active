<?php
session_start();
require_once __DIR__ . '/../db.php';
if (empty($_SESSION['admin'])) { header('Location: login.php'); exit; }
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES['csv_file'])) {
    $f = $_FILES['csv_file']['tmp_name'];
    if (($handle = fopen($f, 'r')) !== false) {
        $pdo->beginTransaction();
        $ins = $pdo->prepare('INSERT INTO tickets (ticket_number, status) VALUES (?, ?) ON DUPLICATE KEY UPDATE status = VALUES(status)');
        $count = 0;
        while (($data = fgetcsv($handle, 1000, ',')) !== false) {
            // Expecting CSV: ticket_number,status
            $ticket = trim($data[0] ?? '');
            $status = strtolower(trim($data[1] ?? 'inactive'));
            if ($ticket === '') continue;
            if (!in_array($status, ['active','inactive','winner'])) $status = 'inactive';
            try {
                $ins->execute([$ticket, $status]);
                $count++;
            } catch (Exception $e) {
                // skip individual errors
            }
        }
        $pdo->commit();
        fclose($handle);
        $msg = "Imported $count tickets.";
    } else {
        $msg = 'Could not open file.';
    }
}
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Upload CSV</title><link rel="stylesheet" href="../css/style.css"></head><body>
<div class="container">
  <h1>Upload CSV (ticket_number,status)</h1>
  <?php if ($msg) echo '<p class="success">'.htmlspecialchars($msg).'</p>'; ?>
  <form method="post" enctype="multipart/form-data">
    <input type="file" name="csv_file" accept=".csv" required>
    <button type="submit">Upload</button>
  </form>
  <p>CSV format example:<br>ABC123,active<br>XYZ999,winner</p>
  <p><a href="dashboard.php">Back</a></p>
</div>
</body></html>
