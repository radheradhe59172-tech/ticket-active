<?php
session_start();
require_once __DIR__ . '/../db.php';
if (empty($_SESSION['admin'])) { header('Location: login.php'); exit; }

$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $stmt = $pdo->prepare('SELECT * FROM tickets WHERE ticket_number LIKE ? ORDER BY created_at DESC LIMIT 200');
    $stmt->execute(["%$search%"]);
    $rows = $stmt->fetchAll();
} else {
    $rows = $pdo->query('SELECT * FROM tickets ORDER BY created_at DESC LIMIT 100')->fetchAll();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['change_status'])) {
    $tn = $_POST['ticket_number'] ?? '';
    $status = $_POST['status'] ?? 'inactive';
    $upd = $pdo->prepare('UPDATE tickets SET status = ? WHERE ticket_number = ?');
    $upd->execute([$status, $tn]);
    $msg = 'Status updated';
    header('Location: tickets.php?q=' . urlencode($tn));
    exit;
}
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Tickets</title><link rel="stylesheet" href="../css/style.css"></head><body>
<div class="container">
  <h1>Tickets</h1>
  <form method="get" style="margin-bottom:10px;"><input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search ticket"></input><button type="submit">Search</button></form>
  <?php if (!empty($rows)): ?>
    <table class="admin-table"><tr><th>Ticket</th><th>Status</th><th>Created</th><th>Action</th></tr>
    <?php foreach($rows as $r): ?>
      <tr>
        <td><?php echo htmlspecialchars($r['ticket_number']); ?></td>
        <td><?php echo htmlspecialchars($r['status']); ?></td>
        <td><?php echo htmlspecialchars($r['created_at']); ?></td>
        <td>
          <form method="post" style="display:inline;"><input type="hidden" name="ticket_number" value="<?php echo htmlspecialchars($r['ticket_number']); ?>">
            <select name="status">
              <option value="active" <?php if($r['status']=='active') echo 'selected'; ?>>Active</option>
              <option value="inactive" <?php if($r['status']=='inactive') echo 'selected'; ?>>Inactive</option>
              <option value="winner" <?php if($r['status']=='winner') echo 'selected'; ?>>Winner</option>
            </select>
            <button type="submit" name="change_status">Update</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </table>
  <?php else: ?>
    <p>No tickets found.</p>
  <?php endif; ?>
  <p><a href="dashboard.php">Back</a></p>
</div>
</body></html>
